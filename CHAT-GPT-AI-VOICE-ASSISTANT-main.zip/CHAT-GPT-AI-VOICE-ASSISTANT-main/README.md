# CHAT GPT BASE AI VOICE ASSISTANT

## Installation

To install the required libraries, run the following commands in your terminal:

```bash
sudo apt-get install portaudio19-dev
sudo apt-get install python3-pyaudio
pip install speechrecognition
pip install SpeechRecognition pyaudio
pip install pyttsx3
pip install openai==0.28
sudo apt-get install espeak
sudo apt-get install flac
``````

# To Run

```bash
python chat_gpt_ai_voice_assistant.py
``````
